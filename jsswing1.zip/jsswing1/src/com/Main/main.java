package com.Main;

import com.ui.Home1;

public class main {
public static void main(String[] args) {
	new Home1();
}
}
