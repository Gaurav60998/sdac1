/**
 * 
 */
/**
 * 
 */
module jsswing1 {
	requires java.desktop;
	requires java.sql;
}