package swing;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class home extends JFrame {

	JLabel jLabel;
	JButton button1,button2;
	public home() {
		setLayout(null);
		jLabel = new JLabel("HOME PAGE");
		button1 = new JButton("save Employee");
		button1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new EmployeeAdd();
				dispose();
				
			}
		});
		button2 = new JButton("Delete Employee");
		button2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new EmployeeDelete();
				dispose();
				
			}
		});
		
		jLabel.setBounds(140,50,100,60);
		button1.setBounds(120,100,130,50);
		button2.setBounds(120,170,130,50);
		
		add(jLabel);
		add(button1);
		add(button2);
		setSize(400, 400);
		setVisible(true);
}
	public static void main(String[] args) {
		new home();
	}
}
